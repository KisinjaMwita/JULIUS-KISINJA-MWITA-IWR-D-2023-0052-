class Machine:
    def perform_maintenance(self):
        print("Generic maintenance performed.")

class WaterPump(Machine):
    def perform_maintenance(self):
        print("Clean filter and check valves.")

class Generator(Machine):
    def perform_maintenance(self):
        print("Change oil and test battery.")

def service_machine(machine_object):
    machine_object.perform_maintenance()

service_machine(WaterPump())
service_machine(Generator())