from abc import ABC, abstractmethod

class FarmTask(ABC):
    @abstractmethod
    def execute(self):
        pass

class PloughingTask(FarmTask):
    def execute(self):
        print("Executing ploughing on Field A.")

class SowingTask(FarmTask):
    def execute(self):
        print("Executing sowing on Field B.")

tasks = [PloughingTask(), SowingTask()]
for task in tasks:
    task.execute()