# Question 9: Student Records and Averages

students = {
    'IWR/D/2023/0052': {'name': 'JULIUS KISINJA MWITA', 'assignment_scores': [75, 85, 90]}
}

def calculate_average(reg_no):
    student = students.get(reg_no)
    if student:
        return sum(student['assignment_scores']) / len(student['assignment_scores'])
    return "Student not found"

print("Average score:", calculate_average('IWR/D/2023/0052'))