from datetime import datetime, timedelta

class Crop:
    def __init__(self, name, planting_date, days_to_maturity):
        self.name = name
        self.planting_date = datetime.strptime(planting_date, "%Y-%m-%d")
        self.days_to_maturity = days_to_maturity

    def calculate_harvest_date(self):
        return self.planting_date + timedelta(days=self.days_to_maturity)

crop = Crop("Maize", "2025-03-01", 120)
print("Expected harvest date:", crop.calculate_harvest_date().strftime("%Y-%m-%d"))