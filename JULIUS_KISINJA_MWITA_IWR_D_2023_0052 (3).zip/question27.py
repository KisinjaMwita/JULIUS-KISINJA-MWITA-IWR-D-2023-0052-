class Tractor:
    def __init__(self, model, horsepower):
        self.model = model
        self.horsepower = horsepower

tractors = {
    'T 123 SUA': Tractor("MF 290", 75),
    'T 456 SUA': Tractor("John Deere", 85)
}

def lookup_tractor(plate):
    tractor = tractors.get(plate)
    if tractor:
        print(f"Tractor {plate} horsepower: {tractor.horsepower}")
    else:
        print("Tractor not found.")

lookup_tractor('T 123 SUA')