# Question 8: Pesticide Database Query

pesticides = {
    'Roundup': {'active_ingredient': 'Glyphosate', 'application_rate': '2 L/ha'},
    'Atrazine': {'active_ingredient': 'Atrazine', 'application_rate': '1.5 L/ha'},
    'GlyphoMax': {'active_ingredient': 'Glyphosate', 'application_rate': '2.5 L/ha'}
}

glyphosate_pesticides = [name for name, details in pesticides.items() if details['active_ingredient'] == 'Glyphosate']
print("Pesticides with Glyphosate:", glyphosate_pesticides)