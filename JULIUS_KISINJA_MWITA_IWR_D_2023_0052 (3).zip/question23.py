class Crop:
    def get_water_needs(self):
        return "Requires regular watering."

class Sugarcane(Crop):
    def get_water_needs(self):
        return "Requires high water volume."

class Sorghum(Crop):
    def get_water_needs(self):
        return "Is drought-resistant, requires minimal water."

crops = [Sugarcane(), Sorghum()]
for crop in crops:
    print(crop.get_water_needs())