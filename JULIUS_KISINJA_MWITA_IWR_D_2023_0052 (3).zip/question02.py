# Question 2: Fertilizer Cost Calculation

rates = [120, 150, 100, 180, 130]
cost_per_kg = 1500
total_costs = [rate * cost_per_kg for rate in rates]
print("Total fertilizer costs for each field (in TZS):", total_costs)