class IrrigationPump:
    def __init__(self, pump_type, flow_rate):
        self.pump_type = pump_type
        self.flow_rate = flow_rate  # in liters per minute

    def calculate_water_pumped(self, hours):
        total_liters = self.flow_rate * hours * 60
        return total_liters / 1000  # in cubic meters

pump = IrrigationPump("Electric", 30)
print("Water pumped (cubic meters):", pump.calculate_water_pumped(2))