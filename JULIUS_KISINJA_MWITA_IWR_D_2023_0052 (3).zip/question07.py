# Question 7: Crop Nutrient Lookup

crop_nutrients = {'Maize': {'N': 120, 'P': 60, 'K': 60},
                  'Rice': {'N': 100, 'P': 50, 'K': 50}}

crop = input("Enter crop name: ")
nutrient = input("Enter nutrient (N/P/K): ")

if crop in crop_nutrients and nutrient in crop_nutrients[crop]:
    print(f"{nutrient} requirement for {crop} is {crop_nutrients[crop][nutrient]} kg/ha")
else:
    print("Crop or nutrient not found.")