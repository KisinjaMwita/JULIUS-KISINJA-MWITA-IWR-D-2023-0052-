# Question 5: Tractor Fuel Cost Log

fuel_log = [45.5, 52.0, 48.3, 42.1, 55.6]
price_per_liter = 2800
total_cost = sum(fuel_log) * price_per_liter
print("Total fuel cost (TZS):", total_cost)