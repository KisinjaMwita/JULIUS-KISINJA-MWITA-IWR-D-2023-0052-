class FarmEquipment:
    def __init__(self, name, purchase_price):
        self.name = name
        self.purchase_price = purchase_price

class Tractor(FarmEquipment):
    def __init__(self, name, purchase_price, horsepower):
        super().__init__(name, purchase_price)
        self.horsepower = horsepower

class Harvester(FarmEquipment):
    def __init__(self, name, purchase_price, cutting_width):
        super().__init__(name, purchase_price)
        self.cutting_width = cutting_width

tractor = Tractor("MF 290", 30000000, 75)
harvester = Harvester("John Deere", 50000000, 4.5)

print("Tractor horsepower:", tractor.horsepower)
print("Harvester cutting width:", harvester.cutting_width, "meters")