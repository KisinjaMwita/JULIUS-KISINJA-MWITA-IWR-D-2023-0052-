# Question 6: Farm Inventory Management

def get_quantity(inventory, item_name):
    return inventory.get(item_name, "Item not found")

inventory = {'Tractor': 2, 'Plough': 5, 'Seeds': 100}
item = 'Tractor'
print(f"Quantity of {item}:", get_quantity(inventory, item))