class Crop:
    def __init__(self, name, yield_per_hectare):
        self.name = name
        self.yield_per_hectare = yield_per_hectare

class Field:
    def __init__(self, size_in_hectares):
        self.size_in_hectares = size_in_hectares
        self.crops = []

    def add_crop(self, crop):
        self.crops.append(crop)

    def get_total_yield(self):
        total_yield = 0
        for crop in self.crops:
            total_yield += crop.yield_per_hectare * self.size_in_hectares
        return total_yield

field = Field(2)
field.add_crop(Crop("Maize", 3.5))
field.add_crop(Crop("Beans", 1.2))
print("Total estimated yield (tonnes):", field.get_total_yield())