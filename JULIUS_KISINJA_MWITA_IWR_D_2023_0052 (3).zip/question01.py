# Question 1: Crop Yield Data Analysis

yield_data = [3.5, 4.2, 3.9, 4.5, 5.1, 4.8, 5.5, 5.3, 5.8, 6.2]

# 1. Calculate average yield
average_yield = sum(yield_data) / len(yield_data)
print("Average yield:", average_yield)

# 2. Year with highest and lowest yield
highest_yield = max(yield_data)
lowest_yield = min(yield_data)
print("Highest yield:", highest_yield)
print("Lowest yield:", lowest_yield)

# 3. Years with yield above 5.0 tonnes
above_5_years = sum(1 for y in yield_data if y > 5.0)
print("Number of years yield > 5.0 tonnes:", above_5_years)