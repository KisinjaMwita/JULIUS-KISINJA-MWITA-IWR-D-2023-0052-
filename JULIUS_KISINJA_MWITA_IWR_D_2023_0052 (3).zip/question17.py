class Crop:
    def planting_instructions(self):
        print("Plant seeds at the beginning of the rainy season.")

class CerealCrop(Crop):
    def __init__(self, grain_type):
        self.grain_type = grain_type

class LegumeCrop(Crop):
    def __init__(self, nitrogen_fixing):
        self.nitrogen_fixing = nitrogen_fixing

cereal = CerealCrop("Wheat")
legume = LegumeCrop(True)

cereal.planting_instructions()
legume.planting_instructions()