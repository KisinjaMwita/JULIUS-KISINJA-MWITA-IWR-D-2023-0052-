class FarmAnimal:
    def __init__(self, species):
        self.species = species

class Crop:
    def __init__(self, name):
        self.name = name

class Farm:
    def __init__(self, name):
        self.name = name
        self.animals = []
        self.fields = {}

    def add_animal(self, animal):
        self.animals.append(animal)

    def plant_crop(self, field_name, crop):
        self.fields[field_name] = crop

    def get_daily_report(self):
        print(f"Total animals: {len(self.animals)}")
        print("Crops per field:")
        for field, crop in self.fields.items():
            print(f"{field}: {crop.name}")

farm = Farm("SUA Demo Farm")
farm.add_animal(FarmAnimal("Cow"))
farm.add_animal(FarmAnimal("Chicken"))
farm.plant_crop("Field A", Crop("Maize"))
farm.plant_crop("Field B", Crop("Rice"))
farm.get_daily_report()