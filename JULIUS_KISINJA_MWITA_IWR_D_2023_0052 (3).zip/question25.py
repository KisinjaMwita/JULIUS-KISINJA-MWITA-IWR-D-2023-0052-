class Plant:
    def harvest(self):
        print("Harvesting in a generic way.")

class FruitTree(Plant):
    def harvest(self):
        print("Harvest by picking fruits carefully.")

class RootVegetable(Plant):
    def harvest(self):
        print("Harvest by digging up from the soil.")

plants = [FruitTree(), RootVegetable()]
for p in plants:
    p.harvest()