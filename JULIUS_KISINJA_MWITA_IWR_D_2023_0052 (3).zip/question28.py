class Pest:
    def damage_report(self):
        return "Generic pest damage."

class InsectPest(Pest):
    def damage_report(self):
        return "Insects eating leaves."

class FungalPest(Pest):
    def damage_report(self):
        return "Fungal infection on stems."

class Crop:
    def __init__(self, name):
        self.name = name
        self.pests = []

    def add_pest(self, pest):
        self.pests.append(pest)

    def generate_pest_report(self):
        for pest in self.pests:
            print(pest.damage_report())

crop = Crop("Tomato")
crop.add_pest(InsectPest())
crop.add_pest(FungalPest())
crop.generate_pest_report()