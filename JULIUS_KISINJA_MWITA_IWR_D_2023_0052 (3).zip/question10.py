# Question 10: Irrigation Water Consumption

irrigation_schedule = {
    'Monday': 30,
    'Tuesday': 20,
    'Wednesday': 25,
    'Thursday': 40,
    'Friday': 35,
    'Saturday': 30,
    'Sunday': 15
}

flow_rate = 20  # liters per minute
total_minutes = sum(irrigation_schedule.values())
total_water = total_minutes * flow_rate

print("Total water consumed (liters):", total_water)