class Livestock:
    def __init__(self, species, weight):
        self.species = species
        self.weight = weight

class Cattle(Livestock):
    def calculate_feed_ratio(self):
        return self.weight * 0.02

class Poultry(Livestock):
    def calculate_feed_ratio(self):
        return self.weight * 0.05

cow = Cattle("Cow", 400)
chicken = Poultry("Chicken", 2)

print("Cow feed (kg):", cow.calculate_feed_ratio())
print("Chicken feed (kg):", chicken.calculate_feed_ratio())