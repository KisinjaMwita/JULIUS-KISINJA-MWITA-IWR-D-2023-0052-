class FarmAnimal:
    def __init__(self, species, age, purpose):
        self.species = species
        self.age = age
        self.purpose = purpose

    def get_details(self):
        return f"Species: {self.species}, Age: {self.age} years, Purpose: {self.purpose}"

animal1 = FarmAnimal("Cow", 3, "Dairy")
animal2 = FarmAnimal("Goat", 2, "Meat")

print(animal1.get_details())
print(animal2.get_details())