# Question 4: Soil pH Analysis with NumPy

import numpy as np

ph_values = np.array([6.2, 6.5, 5.8, 7.1, 6.0, 5.5, 6.8, 6.3, 5.9, 6.6])
avg_ph = np.mean(ph_values)
acidic_count = np.sum(ph_values < 6.0)
categories = []

for ph in ph_values:
    if ph < 6.0:
        categories.append("Acidic")
    elif 6.0 <= ph <= 7.0:
        categories.append("Neutral")
    else:
        categories.append("Alkaline")

print("Average pH:", avg_ph)
print("Number of acidic samples:", acidic_count)
print("Soil categories:", categories)