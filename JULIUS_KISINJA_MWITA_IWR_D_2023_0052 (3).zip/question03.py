# Question 3: Weekly Rainfall Analysis

rainfall = [10.2, 0.0, 5.5, 1.2, 8.0, 0.0, 3.5]
total_rainfall = sum(rainfall)
dry_days = ["Day " + str(i+1) for i, rain in enumerate(rainfall) if rain == 0.0]
print("Total weekly rainfall (mm):", total_rainfall)
print("Days with no rainfall:", dry_days)