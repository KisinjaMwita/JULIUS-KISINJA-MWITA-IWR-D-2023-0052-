from abc import ABC, abstractmethod
import random

class AgriculturalSensor(ABC):
    @abstractmethod
    def read_data(self):
        pass

class SoilMoistureSensor(AgriculturalSensor):
    def read_data(self):
        return random.uniform(10.0, 40.0)

class AirTemperatureSensor(AgriculturalSensor):
    def read_data(self):
        return random.uniform(20.0, 35.0)

soil_sensor = SoilMoistureSensor()
air_sensor = AirTemperatureSensor()

print("Soil moisture:", soil_sensor.read_data())
print("Air temperature:", air_sensor.read_data())